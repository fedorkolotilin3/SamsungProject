package com.example.samsungproject;

public class Data {

    private static String information1;
    private static String information2;
    private static String information3;


    public static void upLoadData(String nInformation1, String nInformation2, String nInformation3){

        information1 = nInformation1;
        information2 = nInformation2;
        information3 = nInformation3;

    }


}
